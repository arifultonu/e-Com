package com.ecom.jwtauthservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtauthserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
