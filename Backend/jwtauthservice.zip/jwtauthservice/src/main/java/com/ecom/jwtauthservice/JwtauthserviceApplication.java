package com.ecom.jwtauthservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtauthserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtauthserviceApplication.class, args);
	}

}
